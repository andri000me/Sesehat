    <!-- Body -->
    <div class="container-fluid">
        <div class="row content-constraint-head">
            <h1>List Dokter Tersedia</h1>
        </div>
        <div class="row content-constraint-body">
          <div class="col-xl-3 col-lg-4 col-md-6 col-sm-12 gridPad">
            <div class="card text-center small-center">
                <div>
                  <img class="card-img-top" src="<?php echo base_url(); ?>assets/images/Placeholder/Nishino.jpg" alt="Card image cap">
                </div>
                <div class="card-body">
                    <h5 class="card-title">Card title</h5>
                    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    <a href="#" class="btn btn-primary">Lihat Detail</a>
                </div>
              </div>
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-sm-12 gridPad">
            <div class="card text-center small-center">
                <div>
                  <img class="card-img-top" src="<?php echo base_url(); ?>assets/images/Placeholder/Tasya.jpg" alt="Card image cap" >
                </div>
                <div class="card-body">
                    <h5 class="card-title">Card title</h5>
                    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    <a href="#" class="btn btn-primary">Lihat Detail</a>
                </div>
            </div>
          </div>
            
          <div class="col-xl-3 col-lg-4 col-md-6 col-sm-12 gridPad">
            <div class="card text-center small-center">
                <div>
                  <img class="card-img-top" src="<?php echo base_url(); ?>assets/images/Placeholder/1301180513.jpg" alt="Card image cap" >
                </div>
                <div class="card-body">
                    <h5 class="card-title">Pog</h5>
                    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    <a href="#" class="btn btn-primary">Lihat Detail</a>
                </div>
              </div>
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-sm-12 gridPad">
            <div class="card text-center small-center">
                <div>
                  <img class="card-img-top" src="<?php echo base_url(); ?>assets/images/Placeholder/Tasya.jpg" alt="Card image cap" >
                </div>
                <div class="card-body">
                    <h5 class="card-title">Card title</h5>
                    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    <a href="#" class="btn btn-primary">Lihat Detail</a>
                </div>
              </div>
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-sm-12 gridPad">
            <div class="card text-center small-center">
                <div>
                  <img class="card-img-top" src="<?php echo base_url(); ?>assets/images/Placeholder/Tasya.jpg" alt="Card image cap" >
                </div>
                <div class="card-body">
                    <h5 class="card-title">Card title</h5>
                    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    <a href="#" class="btn btn-primary">Lihat Detail</a>
                </div>
              </div>
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-sm-12 gridPad">
            <div class="card text-center small-center">
                <div>
                  <img class="card-img-top" src="<?php echo base_url(); ?>assets/images/Placeholder/Nishino.jpg" alt="Card image cap" >
                </div>
                <div class="card-body">
                    <h5 class="card-title">Nishino</h5>
                    <p class="card-text" style="overflow: hidden;">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Ratione eveniet eum maxime dignissimos distinctio voluptates sapiente corrupti minus similique nemo, debitis laborum eius alias? Totam sint non ea molestiae reprehenderit?Lorem ipsum, dolor sit amet consectetur adipisicing elit. Illum dolor consectetur consequuntur quos vel obcaecati deleniti natus, ipsum dolore. Et eveniet incidunt sequi, officiis quo excepturi tempore nulla fuga reprehenderit! Lorem ipsum dolor sit amet consectetur adipisicing elit. Labore sequi possimus ad ullam hic aliquam illo ab porro commodi architecto eaque soluta aspernatur excepturi distinctio vitae modi dolor, necessitatibus fuga.</p>
                    <a href="#" class="btn btn-primary">Lihat Detail</a>
                </div>
              </div>
          </div>

          <div class="col-xl-3 col-lg-4 col-md-6 col-sm-12 gridPad">
            <div class="card text-center small-center">
                <div>
                  <img class="card-img-top" src="<?php echo base_url(); ?>assets/images/Placeholder/Tasya.jpg" alt="Card image cap" >
                </div>
                <div class="card-body">
                    <h5 class="card-title">Darklord</h5>
                    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                    <a href="#" class="btn btn-primary">Lihat Detail</a>
                </div>
              </div>
          </div>
        </div>
    </div>
  
</body>
</html>