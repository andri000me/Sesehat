    <!-- Body -->
    <div class="content-constraint-head">
      <h1>List Jadwal Janjian</h1>
    </div>
    <div class="container-fluid content-constraint-body">
      <div class="row list-card">
        <div class="text-lg-left text-md-center text-xs-left col-lg-4 col-md-6">
          <h3>Nama: Siayam Petualang</h3>
          <h3>Jenis: Kelamin Laki-Laki</h3>
        </div>
        <div class="text-lg-left text-md-center text-xs-left col-lg-4 col-md-6">
          <h3>Metode Konsultasi: <span>Chat via WA</span> </h3>
          <h3>Waktu Konsultasi: <span>20 April 2020</span> </h3>
        </div>
        <div class="col-lg-2 col-md-6 m-auto px-3 py-2">
          <button type="submit" class="btn btn-outline-primary btn-block">Tolak</button>
        </div>
        <div class="col-lg-2 col-md-6 m-auto px-3 py-2">
          <button type="submit" class="btn btn-primary btn-block">Terima</button>
        </div>
      </div>
      
    </div>
  
</body>
</html>   