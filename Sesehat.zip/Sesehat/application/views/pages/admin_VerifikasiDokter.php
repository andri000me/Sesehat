    <!-- Body -->
    <div class="content-constraint-head">
      <h1>Verifikasi Dokter</h1>
    </div>
    <div class="container-fluid content-constraint-body">
      <div class="row list-card">
        <div class="text-lg-left text-md-center text-xs-left m-md-auto col-lg-4 col-md-6">
          <h3>Nama: Dr. Munap</h3>
          <h3>Jenis Kelamin: Perempuan</h3>
        </div>
        <div class="text-lg-left text-md-center text-xs-left m-md-auto col-lg-5 col-md-6">
          <h3>Username: <span>AyamAyam</span> </h3>
          <h3>Gelar: <span>S2 Psikoterapi UNUN</span> </h3>
        </div>
        <div class="col-lg-3 col-sm-12 m-auto py-2">
          <button type="submit" class="btn btn-outline-primary btn-block">Verifikasi</button>
        </div>
      </div>
      
    </div>
  
</body>
</html>   