  <!-- Body -->
  <div class="container-fluid">
    <div class="row" style="padding-top: 72px;">

    </div>
    <div class="row content-constraint-body justify-content-center" style="margin-top: 100px; padding: 0 4em;">
      
        <div class="bg-white text-center " style="padding:8em 6em; border-radius: 8px; max-width: 960px; width: auto;">
          <div>
            <img src="/images/UI/Wink Smile.svg" alt=";)">
            <p class="text-center" style="padding-top: 30px;">Silahkan Cek pada halaman <b>Status Jadwal</b> <br> untuk mengetahui jadwal yang di request diterima sama dokter atau tidak</p>
          </div>
          
        </div>  
      
    </div>
</div>

  </div>
  

</body>

</html>